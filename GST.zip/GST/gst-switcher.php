<?php
/*
Plugin Name: GST Switcher
Description: Switch between GST and non-GST prices in WooCommerce.
Version: 1.0
Author: Your Name
*/

// Plugin initialization
function gst_switch_init() {
    add_option('gst_switch', 'on'); // 'on' by default
}
register_activation_hook(__FILE__, 'gst_switch_init');

// Plugin deactivation
function gst_switch_deactivate() {
    delete_option('gst_switch');
}
register_deactivation_hook(__FILE__, 'gst_switch_deactivate');

// Enqueue the JavaScript file
function enqueue_gst_switcher_script() {
    wp_enqueue_script('gst-switcher', plugin_dir_url(__FILE__) . 'gst-switcher.js', array('jquery'), '1.0', true);
    wp_localize_script('gst-switcher', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'enqueue_gst_switcher_script');

// Rename VAT to GST
function rename_vat_to_gst($price_format) {
    return str_replace('VAT', 'GST', $price_format);
}
add_filter('woocommerce_price_format', 'rename_vat_to_gst', 10, 1);

// Apply GST Adjustment
function apply_gst_adjustment($price, $product) {
    if (get_option('gst_switch') === 'on') {
        // Add 10% to price
        $price *= 1.10;
    } else {
        // Subtract 10% from price
        $price *= 0.90;
    }
    return $price;
}
add_filter('woocommerce_product_get_price', 'apply_gst_adjustment', 10, 2);
add_filter('woocommerce_product_variation_get_price', 'apply_gst_adjustment', 10, 2);

// AJAX callback to update prices
function update_prices_callback() {
    $gst_status = $_POST['gst_status'];
    update_option('gst_switch', $gst_status);
    echo 'Prices updated successfully';
    die();
}
add_action('wp_ajax_update_prices', 'update_prices_callback');
add_action('wp_ajax_nopriv_update_prices', 'update_prices_callback');

// Create a Shortcode for Switch Button
function gst_switch_shortcode() {
    $gst_status = get_option('gst_switch');
    ob_start();
    ?>
    <div class="gst-switch">
        <label for="gst-toggle">GST:</label>
        <input type="checkbox" id="gst-toggle" name="gst-toggle" <?php echo ($gst_status === 'on') ? 'checked' : ''; ?>>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('gst_switch', 'gst_switch_shortcode');
function enqueue_gst_switcher_styles() {
    wp_enqueue_style('gst-switcher-styles', plugin_dir_url(__FILE__) . 'gst-switcher.css', array(), '1.0');
}
add_action('wp_enqueue_scripts', 'enqueue_gst_switcher_styles');
