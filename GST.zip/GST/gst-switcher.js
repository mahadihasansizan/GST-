jQuery(document).ready(function ($) {
    // Function to update prices when the GST switch is toggled
    function updatePrices() {
        var gstStatus = $('#gst-toggle').prop('checked') ? 'on' : 'off';
        $.ajax({
            type: 'POST',
            url: ajax_object.ajax_url, // Provided by WordPress
            data: {
                action: 'update_prices',
                gst_status: gstStatus
            },
            success: function (response) {
                // Update prices on the page
                $('.price').each(function () {
                    var currentPrice = parseFloat($(this).text());
                    if (gstStatus === 'on') {
                        currentPrice *= 1.10; // Add 10% for GST
                    } else {
                        currentPrice *= 0.90; // Subtract 10% for non-GST
                    }
                    $(this).text(currentPrice.toFixed(2));
                });
            }
        });
    }

    // Event handler for the GST switch
    $('#gst-toggle').change(function () {
        updatePrices();
    });
});
